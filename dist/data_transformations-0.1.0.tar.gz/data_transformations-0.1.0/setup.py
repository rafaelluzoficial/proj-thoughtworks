# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['data_transformations', 'data_transformations.citibike']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.20.2,<2.0.0',
 'pandas>=1.2.4,<2.0.0',
 'pyarrow>=4.0.0,<5.0.0',
 'pyspark>=3.1.1,<4.0.0']

setup_kwargs = {
    'name': 'data-transformations',
    'version': '0.1.0',
    'description': 'data transformations',
    'long_description': None,
    'author': 'ThoughtWorks',
    'author_email': 'info@thoughtworks.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
